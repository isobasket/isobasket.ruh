
// Add the TikTok username (without @) to show the TikTok follow button.
const CONFIG = { whatsapp: '966543825044', tiktok: 'isobasket7' };
if (CONFIG.tiktok) { const t = document.getElementById('followTt'); t.href = 'https://www.tiktok.com/@' + CONFIG.tiktok; t.textContent = 'TikTok · @' + CONFIG.tiktok; t.hidden = false; }
let lang = 'en', settings = { date: 'To be announced / يُعلن قريباً', venue: 'To be announced / يُعلن قريباً', fee: 'To be announced / يُعلن قريباً', prize: '', results: [] };
const $ = id => document.getElementById(id), text = (en, ar) => lang === 'ar' ? ar : en;
function node(tag, value) { const n = document.createElement(tag); n.textContent = value ?? ''; return n; }

async function api(path, options = {}) {
  const response = await fetch(path, { credentials: 'same-origin', ...options, headers: { 'Content-Type': 'application/json', ...options.headers } });
  let data = null;
  try { data = await response.json(); } catch {}
  if (!response.ok) { const err = Error(data?.error || 'Request failed'); err.status = response.status; throw err; }
  return data;
}
function icon(name) { const ns = 'http://www.w3.org/2000/svg', svg = document.createElementNS(ns, 'svg'), use = document.createElementNS(ns, 'use'); svg.setAttribute('class', 'ic'); use.setAttribute('href', '#i-' + name); svg.append(use); return svg; }
function cards(id, items) { $(id).replaceChildren(...items.map(([heading, body, ic]) => { const c = node('div', ''); c.className = 'card'; if (ic) { const f = node('div', ''); f.className = 'fi'; f.append(icon(ic)); c.append(f); } c.append(node('h3', heading), node('p', body)); return c; })); }
const tba = v => !v || /to be announced|يُعلن/i.test(v);
const firstLine = v => String(v || '').split(/\n/)[0].trim();
function chips() {
  $('heroChips').replaceChildren(...[['cal', settings.date], ['pin', settings.venue], ['trophy', firstLine(settings.prize)]].filter(([, v]) => !tba(v)).map(([ic, v]) => { const c = node('span', ''); c.className = 'chip'; c.append(icon(ic), node('span', v)); c.title = v; return c; }));
}
let spots = null;
function renderSpots() {
  if (!spots) return;
  const confirmed = Math.min(spots.confirmed, spots.total), left = spots.total - confirmed;
  $('spots').hidden = false;
  $('spotsLeft').textContent = left;
  $('spotsText').textContent = left ? text(left === 1 ? 'spot left' : 'spots left', 'مقعداً متبقياً') : text('Fully booked · join the waitlist', 'اكتمل العدد · سجّل في قائمة الانتظار');
  $('spotsConfirmed').textContent = text(`${confirmed} confirmed`, `${confirmed} مؤكَّد`);
  $('spotsRegistered').textContent = text(`${spots.registered} registered`, `${spots.registered} مسجّل`);
  $('spotsMeter').setAttribute('aria-valuenow', confirmed);
  requestAnimationFrame(() => { $('spotsBar').style.width = (confirmed / spots.total * 100) + '%'; });
}
const rulesEn = ['Inside the arc: 1 point. Outside: 2 points.','Check at the top. Make it, take it. Clear behind the arc after a defensive rebound or steal.','12-second shot clock. Clock expires before rim contact: turnover.','Swiss and Round of 16: first to 11, 10-minute cap, win by 1. Quarterfinals: first to 21, 25-minute cap, win by 1. Semifinals and final: first to 21, win by 2, 25-minute cap.','At the time cap, the higher score wins; a tie goes to the next basket, overriding the win-by-two rule.','Referee calls clear fouls. Ball at the top; no free throws. Unsportsmanlike conduct awards the opponent 1 point and possession; a second offense means disqualification.','No timeouts or substitutions. One injury break up to 2 minutes. Be ready 30 minutes early; 5 minutes late after being called means a forfeit.','Tournament dates, venue, and final operational details will be confirmed by the organizer.'];
const rulesAr = ['داخل القوس نقطة وخارجه نقطتان.','تبادل الكرة من أعلى المنطقة، ومن يسجل يحتفظ بالكرة. أخرج الكرة خلف القوس بعد الاستحواذ الدفاعي.','ساعة الهجوم 12 ثانية. انتهاء الساعة قبل لمس الحلقة يعني خسارة الكرة.','السويسري ودور الـ16: حتى 11 خلال 10 دقائق بفارق نقطة. ربع النهائي: حتى 21 خلال 25 دقيقة بفارق نقطة. نصف النهائي والنهائي: حتى 21 بفارق نقطتين خلال 25 دقيقة.','عند انتهاء الوقت يفوز المتقدم. عند التعادل تفوز السلة التالية، استثناءً من شرط فارق النقطتين.','يحتسب الحكم المخالفات الواضحة؛ الكرة من الأعلى دون رميات حرة. السلوك غير الرياضي يمنح الخصم نقطة والكرة؛ تكراره يعني الاستبعاد.','لا مهلات أو تبديلات. توقف إصابة واحد حتى دقيقتين. الحضور قبل البداية بنصف ساعة والتأخر 5 دقائق بعد النداء يعني الانسحاب.','يؤكد المنظم التاريخ والمكان والتفاصيل التشغيلية النهائية.'];
function render() {
  document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-en]').forEach(n => n.textContent = n.dataset[lang]);
  $('language').textContent = lang === 'en' ? 'العربية' : 'English';
  $('feeBar').textContent = settings.fee;
  renderPayment(); chips(); renderSpots();
  cards('facts', [[text('Players', 'اللاعبون'), '32 · 1v1', 'users'], [text('Date', 'التاريخ'), settings.date, 'cal'], [text('Venue', 'المكان'), settings.venue, 'pin'], [text('Entry fee', 'الرسوم'), settings.fee, 'card'], ...(settings.prize ? [[text('Prize pool', 'الجوائز'), settings.prize, 'trophy']] : [])]);
  $('mapLink').hidden = tba(settings.venue);
  $('mapLink').href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(settings.venue + ', Riyadh');
  cards('schedule', [[text('Day 1', 'اليوم 1'), text('Swiss rounds 1 and 2 · 32 games · arrival 5:30 PM', 'الجولتان السويسريتان · 32 مباراة · الحضور 5:30 م')], [text('Day 2', 'اليوم 2'), text('Round of 16 and quarterfinals · 12 games · check-in 6:30 PM', 'دور الـ16 وربع النهائي · 12 مباراة · الحضور 6:30 م')], [text('Day 3', 'اليوم 3'), text('Semifinals and final · 3 games · doors 7:00 PM', 'نصف النهائي والنهائي · 3 مباريات · الأبواب 7 م')]]);
  $('ruleList').replaceChildren(...(lang === 'en' ? rulesEn : rulesAr).map(r => node('li', r)));
  cards('results', settings.results.length ? settings.results.map(r => [r.round, [r.a, r.b, r.score].join(' · ')]) : [[text('Awaiting qualifiers', 'بانتظار المتأهلين'), text('Knockout results appear here after the Swiss stage. Check back on Day 2.', 'تظهر نتائج خروج المغلوب هنا بعد المرحلة السويسرية. عُد في اليوم الثاني.')]]);
  if (!settings.results.length) $('results').firstChild.classList.add('empty');
}

const hasBank = () => Boolean(settings.barqIban || settings.stcIban);
function renderPayment() {
  $('payment').hidden = !hasBank();
  $('bankHolder').textContent = settings.bankHolder || ''; $('bankHolderRow').hidden = !settings.bankHolder;
  $('ibans').replaceChildren(...[[text('Barq', 'برق'), settings.barqIban], [text('STC Bank', 'STC Bank'), settings.stcIban]].filter(([, v]) => v).map(([bank, value]) => {
    const c = node('div', ''); c.className = 'card iban';
    const code = node('code', value.replace(/(.{4})/g, '$1 ').trim());
    const copy = node('button', text('Copy IBAN', 'نسخ الآيبان')); copy.type = 'button';
    copy.onclick = async () => { try { await navigator.clipboard.writeText(value); copy.textContent = text('Copied ✓', 'تم النسخ ✓'); } catch { copy.textContent = value; } };
    c.append(node('h3', bank), code, copy); return c;
  }));
  $('sendReceipt').href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent('isobasket – entry fee transfer receipt / إيصال تحويل رسوم المشاركة\nName / الاسم: ');
}

const tabNames = ['Rules', 'How', 'Evenings'];
function tab(name) { tabNames.forEach(n => { $('tab' + n).setAttribute('aria-selected', n === name); $('panel' + n).hidden = n !== name; }); }
tabNames.forEach(n => { $('tab' + n).onclick = () => tab(n); });
$('openInfo').onclick = $('openInfo2').onclick = () => $('info').showModal();
$('navRules').onclick = e => { e.preventDefault(); $('info').showModal(); };
$('closeInfo').onclick = () => $('info').close();
$('info').onclick = e => { if (e.target === $('info')) $('info').close(); };
$('language').onclick = () => { lang = lang === 'en' ? 'ar' : 'en'; render(); };
render();

async function load() {
  try { const content = await api('/api/tournament'); settings = { ...settings, ...Object.fromEntries(Object.entries(content || {}).filter(([, v]) => v !== '' && v != null)) }; render(); } catch {}
}
load();
api('/api/spots').then(d => { spots = d; renderSpots(); }).catch(() => {});

// Fade sections in as they scroll into view
const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 }) : null;
document.querySelectorAll('.reveal').forEach(el => io ? io.observe(el) : el.classList.add('in'));

// ---------- Player registration ----------
$('registration').onsubmit = async e => {
  e.preventDefault();
  const form = e.target;
  if (!form.reportValidity()) return;
  const fields = Object.fromEntries(new FormData(form));
  if (fields.highlights && !/^https:\/\//i.test(fields.highlights)) { $('regStatus').textContent = text('Use an HTTPS highlight link.', 'استخدم رابط HTTPS.'); return; }
  const registration = { name: fields.name.trim(), age: Number(fields.age), city: fields.city.trim(), phone: fields.phone.trim(), height: fields.height ? Number(fields.height) : null, style: fields.style, social: [['TikTok', fields.tiktok], ['Instagram', fields.instagram]].map(([k, v]) => [k, (v || '').trim().replace(/^@?/, '@')]).filter(([, v]) => v.length > 1).map(([k, v]) => k + ': ' + v).join(' · '), highlights: fields.highlights, source: fields.source, consent: true };
  $('submit').disabled = true; $('sendWhatsApp').hidden = true;
  try {
    await api('/api/register', { method: 'POST', body: JSON.stringify(registration) });
    $('regStatus').textContent = hasBank()
      ? text('Your request was saved. Next step: transfer the entry fee using the bank details below and send the receipt on WhatsApp.', 'تم حفظ الطلب. الخطوة التالية: حوّل رسوم المشاركة باستخدام بيانات الحساب أدناه وأرسل الإيصال عبر واتساب.')
      : text('Your request was saved. The organizer will contact you; your place is not yet confirmed.', 'تم حفظ الطلب. سيتواصل المنظم معك؛ لم يتم تأكيد المقعد بعد.');
    if (hasBank()) { $('sendReceipt').href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent('isobasket – entry fee transfer receipt / إيصال تحويل رسوم المشاركة\nName / الاسم: ' + registration.name); $('payment').scrollIntoView({ behavior: 'smooth' }); }
    form.reset();
    api('/api/spots').then(d => { spots = d; renderSpots(); }).catch(() => {});
  } catch {
    $('regStatus').textContent = text('Not saved online. Use the button below to send your details to the organizer.', 'لم يُحفظ الطلب إلكترونياً. استخدم الزر التالي لإرسال بياناتك إلى المنظم.');
    const message = 'isobasket registration\n' + Object.entries(registration).filter(([k, v]) => v && k !== 'consent').map(([k, v]) => k + ': ' + v).join('\n');
    $('sendWhatsApp').href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(message);
    $('sendWhatsApp').hidden = false;
  } finally { $('submit').disabled = false; }
};
