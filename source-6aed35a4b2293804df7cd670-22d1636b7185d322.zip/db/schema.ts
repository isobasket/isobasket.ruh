import { pgTable, serial, text, integer, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";

export const registrations = pgTable("registrations", {
  id: serial().primaryKey(),
  name: text().notNull(),
  age: integer().notNull(),
  city: text().notNull(),
  phone: text().notNull(),
  height: integer(),
  style: text().notNull(),
  social: text().notNull().default(""),
  highlights: text().notNull().default(""),
  source: text().notNull().default(""),
  paid: boolean().notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tournament = pgTable("tournament", {
  id: integer().primaryKey(),
  content: jsonb().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
