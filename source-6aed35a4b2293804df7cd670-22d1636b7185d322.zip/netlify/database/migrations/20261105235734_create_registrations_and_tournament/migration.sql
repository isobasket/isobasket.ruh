CREATE TABLE "registrations" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"age" integer NOT NULL,
	"city" text NOT NULL,
	"phone" text NOT NULL,
	"height" integer,
	"style" text NOT NULL,
	"social" text DEFAULT '' NOT NULL,
	"highlights" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tournament" (
	"id" integer PRIMARY KEY,
	"content" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
