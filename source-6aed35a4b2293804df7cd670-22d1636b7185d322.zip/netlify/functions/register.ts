import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { registrations } from "../../db/schema.js";

const str = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export default async (req: Request) => {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  const name = str(body.name, 80);
  const city = str(body.city, 60);
  const phone = str(body.phone, 24);
  const style = str(body.style, 60);
  const social = str(body.social, 120);
  const highlights = str(body.highlights, 500);
  const source = str(body.source, 40);
  const age = Number(body.age);
  const height = body.height == null || body.height === "" ? null : Number(body.height);

  if (!name || !city || !phone || !style || !source || body.consent !== true) {
    return Response.json({ error: "Missing required fields" }, { status: 400 });
  }
  if (!Number.isInteger(age) || age < 8 || age > 70) {
    return Response.json({ error: "Invalid age" }, { status: 400 });
  }
  if (height !== null && (!Number.isInteger(height) || height < 120 || height > 240)) {
    return Response.json({ error: "Invalid height" }, { status: 400 });
  }
  if (highlights && !/^https:\/\//i.test(highlights)) {
    return Response.json({ error: "Highlight link must use HTTPS" }, { status: 400 });
  }

  await db.insert(registrations).values({ name, age, city, phone, height, style, social, highlights, source });
  return Response.json({ ok: true }, { status: 201 });
};

export const config: Config = { path: "/api/register", method: "POST" };
