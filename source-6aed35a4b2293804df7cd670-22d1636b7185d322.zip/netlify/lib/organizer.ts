import { getUser } from "@netlify/identity";

const ORGANIZER_ROLES = ["organizer", "admin"];

function organizerEmails() {
  return (process.env.ORGANIZER_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

// Returns the signed-in organizer, or an error Response.
// Organizers are accounts whose email is listed in ORGANIZER_EMAILS (or that have an organizer/admin role).
export async function requireOrganizer() {
  const user = await getUser();
  if (!user) return { error: Response.json({ error: "Please sign in." }, { status: 401 }) };
  const email = (user.email ?? "").toLowerCase();
  const allowed =
    (email && organizerEmails().includes(email)) ||
    (user.roles ?? []).some((r) => ORGANIZER_ROLES.includes(r));
  if (!allowed) return { error: Response.json({ error: "This account is not an organizer." }, { status: 403 }) };
  return { user };
}

export function sameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  return !origin || origin === new URL(req.url).origin;
}
